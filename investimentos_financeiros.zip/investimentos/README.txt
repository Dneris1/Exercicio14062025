# Sistema de Gestão de Investimentos Financeiros

## Banco de Dados

Execute o seguinte SQL no seu MySQL:

CREATE DATABASE carteira;
USE carteira;

CREATE TABLE investimentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(100),
    valor DECIMAL(10,2),
    data DATE,
    descricao TEXT
);
