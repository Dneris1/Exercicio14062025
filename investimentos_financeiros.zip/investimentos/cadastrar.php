<?php include('db.php'); ?>

<?php
$msg = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipo = $_POST['tipo'];
    $valor = $_POST['valor'];
    $data = $_POST['data'];
    $descricao = $_POST['descricao'];

    if (empty($tipo) || empty($valor) || empty($data)) {
        $msg = "Preencha todos os campos obrigatórios.";
    } else {
        $stmt = $conn->prepare("INSERT INTO investimentos (tipo, valor, data, descricao) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sdss", $tipo, $valor, $data, $descricao);
        if ($stmt->execute()) {
            $msg = "Investimento cadastrado com sucesso!";
        } else {
            $msg = "Erro ao cadastrar investimento.";
        }
    }
}
?>

<h2>Cadastrar Investimento</h2>
<p><?= \$msg ?></p>
<form method="POST">
    Tipo: <input type="text" name="tipo" required><br><br>
    Valor: <input type="number" step="0.01" name="valor" required><br><br>
    Data: <input type="date" name="data" required><br><br>
    Descrição: <textarea name="descricao"></textarea><br><br>
    <input type="submit" value="Cadastrar">
</form>
<a href="index.php">Voltar</a>