<!DOCTYPE html>
<html>
<head>
    <title>Gestão de Investimentos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Gestão de Investimentos</h1>
    <a href="cadastrar.php">Cadastrar Investimento</a> | 
    <a href="listar.php">Listar Investimentos</a>
</body>
</html>