<?php include('db.php'); ?>

<h2>Lista de Investimentos</h2>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Tipo</th>
        <th>Valor</th>
        <th>Data</th>
        <th>Descrição</th>
    </tr>

<?php
$result = $conn->query("SELECT * FROM investimentos ORDER BY data DESC");

while($row = $result->fetch_assoc()) {
    echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['tipo']}</td>
            <td>R$ {$row['valor']}</td>
            <td>{$row['data']}</td>
            <td>{$row['descricao']}</td>
          </tr>";
}
?>
</table>
<a href="index.php">Voltar</a>